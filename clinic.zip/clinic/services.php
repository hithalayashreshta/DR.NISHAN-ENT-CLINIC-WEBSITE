<?php include("header.php"); ?>
    <!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-option spad set-bg" data-setbg="img/images/serviceimg.png">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Our treatments</h2>
                        <div class="breadcrumb__links">
                            <a href="./index.php">Home</a>
                            <span>treatments</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- treatments Section Begin -->
    <section class="treatments-page spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="treatments__details">
                        <div class="row">
                            <div class="col-lg-8 col-md-6 col-sm-6">
                                <div class="treatments__details__title">
                                    <span>Surgeries</span>
                                    <h3>Endoscopic Sinus Surgery</h3>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="treatments__details__widget">
                                    <div class="rating">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="treatments__details__pic">
                                    <img src="img/services/service1.jpg" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="treatments__sidebar">
                        <div class="treatments__accordion">
                            <div class="treatments__title">
                                <h4><img src="img/icons/treatments-icon.png" alt=""> All treatments</h4>
                            </div>
                            <div class="accordion" id="accordionExample">
                                <div class="card">
                                    <div class="card-heading active">
                                        <a data-toggle="collapse" data-target="#collapseOne">
                                            Surgeries
                                        </a>
                                    </div>
                                    <div id="collapseOne" class="collapse show" data-parent="#accordionExample">
                                        <div class="card-body">
                                            <ul>
                                                <li><a href="#">Endoscopic Sinus Surgery</a></li>
                                                <li><a href="#">Endoscopic Pituitary Surgery</a></li>
                                                <li><a href="#">Endoscopic Repair of CSF Rhinorrhea</a></li>
                                                <li><a href="#">Endoscopic Skull Base Surgery</a></li>
                                                <li><a href="#">Endoscopic Dacryocystorhinostomy</a></li>
                                                <li><a href="#">Endoscopic Adenoidectomy</a></li>
                                                <li><a href="#">Tympanoplasty</a></li>
                                                <li><a href="#">Ossiculoplasty</a></li>
                                                <li><a href="#">Mastoidectomy Vocal Cord Lesions</a></li>
                                                <li><a href="#">Phono Surgery (Voice Restoration Surgeries) </a></li>
                                                <li><a href="#">Septoplasty, Rhinoplasty</a></li>
                                                <li><a href="#">Tonsillectomy, Adenoidectomy</a></li>
                                                <li><a href="#">Paediatric ENT Surgeries</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="treatments__details__text">
                        <p>Endoscopic sinus surgery is a minimally invasive surgical procedure used to treat chronic sinusitis and other sinus-related conditions.</p>
                        <p>During endoscopic sinus surgery, the surgeon inserts a thin, flexible tube with a camera (endoscope) into the nose. The endoscope allows the surgeon to see inside the nasal passages and sinuses. Surgical instruments are then inserted through the nostrils to remove tissue, clear blockages, and improve sinus drainage. The procedure is guided by images from the endoscope displayed on a monitor.</p>
                    </div>
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="treatments__details__item__pic">
                                <img src="img/services/service2.png" alt="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="treatments__details__item__pic">
                                <img src="img/services/service3.jpg" alt="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="treatments__details__item__pic">
                                <img src="img/services/service4.jpg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="treatments__details__desc">
                    <p>At Dr. Nishan ENT Clinic, we specialize in providing comprehensive care for disorders related to the ear, nose, throat, and related structures of the head and neck. ENT specialist is dedicated to delivering personalized, compassionate care to every patient who walks through our doors.
                    </p>
                    <div class="row">
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <ul class="treatments__details__feature">
                                <li><i class="fa fa-check-circle"></i> Expertise </li>
                                <li><i class="fa fa-check-circle"></i> State-of-the-Art Facilities </li>
                                <li><i class="fa fa-check-circle"></i> Compassionate Care </li>
                                <li><i class="fa fa-check-circle"></i> Patient-Centered Approach </li>
                            </ul>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <ul class="treatments__details__feature">
                                <li><i class="fa fa-check-circle"></i> Comprehensive Care </li>
                                <li><i class="fa fa-check-circle"></i> Individualized Treatment Plans </li>
                                <li><i class="fa fa-check-circle"></i> Cutting-Edge Technology </li>
                                <li><i class="fa fa-check-circle"></i> Continuity of Care </li>
                            </ul>
                        </div>
                    </div>
                    <p>If you're experiencing ear, nose, or throat problems, don't wait to seek treatment. Schedule an appointment with us today.</p>
                </div>
            </div>
        </div>
    </section>
    <!-- treatments Section End -->
    <?php include("footer.php");  ?>