
<?php include("header.php");  ?>
    <!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-option spad set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>About Us</h2>
                        <div class="breadcrumb__links">
                            <a href="./index.php">Home</a>
                            <span>About</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- About Section Begin -->
    <section class="about spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="about__video set-bg" data-setbg="img/about-video.jpg">
                        <a href="https://www.youtube.com/watch?v=PXsuI67s2AA" class="play-btn video-popup"><i class="fa fa-play"></i></a>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="about__text">
                        <div class="section-title">
                            <span>ABOUT OUR CLINIC</span>
                            <h2>Welcom to Dr. Nishan ENT Clinic</h2>
                        </div>
                        <p>Dr. Nishan ENT Clinic is renowned for its exceptional care and expertise in ear, nose, and throat (ENT) treatments. The clinic provides comprehensive treatments ranging from diagnosis to advanced treatments for various ENT conditions. Led by Dr. Nishan, a highly skilled and experienced ENT specialist, the clinic is committed to delivering personalized care tailored to each patient's needs. With state-of-the-art facilities and a compassionate team, Dr. Nishan ENT Clinic ensures patients receive the highest standard of medical care, promoting healing and well-being for all who seek their treatments..</p>
                        <ul>
                            <li><i class="fa fa-check-circle"></i> Routine and medical care</li>
                            <li><i class="fa fa-check-circle"></i> Excellence in healthcare</li>
                            <li><i class="fa fa-check-circle"></i> Building a healthy environment</li>
                        </ul>
                        <a href="contact.php" class="primary-btn normal-btn">Contact us</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- About Section End -->

    <!-- Chooseus Section Begin -->
    <section >
        <div class= "container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="consultation__text">
                        <div class="consultation__video set-bg" data-setbg="img/consultation-video.jpg">
                            <a href="https://www.youtube.com/watch?v=PXsuI67s2AA" class="play-btn video-popup"><i class="fa fa-play"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Chooseus Section End -->

    <!-- Testimonials Section Begin -->
    <section class="testimonials spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="section-title">
                        <span>Testimonials</span>
                        <h2>Happy clients</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="testimonial__slider owl-carousel">
                    <div class="col-lg-6">
                        <div class="testimonial__item">
                            <div class="testimonial__author">
                                <div class="testimonial__author__icon">
                                    <i class="fa fa-quote-left"></i>
                                </div>
                                <div class="testimonial__author__text">
                                    <h5>Hitha N</h5>
                                    <span>Patient</span>
                                </div>
                            </div>
                            <div class="rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <p>Dr. Nishan is extremely professional: he takes time to listen and time to explain. A first rate professional experience. Completely satisfied with Dr. Nishan he has been very attentive to my health issues. I had a complicated health problems and he addressed them all. He is very kind and patient. I am very greatful for him . I highly recommend Dr. Nishan if you have any ENT related issues he is very professional and he will show true commitment to solve health issues. I ll assure that you will be in good hands for your treatment . </p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="testimonial__item">
                            <div class="testimonial__author">
                                <div class="testimonial__author__icon">
                                    <i class="fa fa-quote-left"></i>
                                </div>
                                <div class="testimonial__author__text">
                                    <h5>Tushar Vasishta</h5>
                                    <span>Patient</span>
                                </div>
                            </div>
                            <div class="rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <p>I recently visited Dr. Nishan and was impressed with his expertise. He conducted a comprehensive examination, explained the diagnosis clearly, and devised an effective treatment plan. Dr. Nishan's compassionate approach and skillful treatment make him an excellent choice for anyone seeking top-notch ENT care at a very reasonable price. Highly recommended!</p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="testimonial__item">
                            <div class="testimonial__author">
                                <div class="testimonial__author__icon">
                                    <i class="fa fa-quote-left"></i>
                                </div>
                                <div class="testimonial__author__text">
                                    <h5>Mr Madhukiran</h5>
                                    <span>Patient</span>
                                </div>
                            </div>
                            <div class="rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <p>Dr. Nishan is a standout ENT specialist in Mysore. Under his care, my deviated nasal surgery was a success, and I'm feeling significantly better. His thorough explanations and attentive approach made me feel informed and comfortable throughout the process. The results have been remarkable—I'm breathing easier and enjoying improved quality of life. Dr. Nishan's expertise and compassionate staff make him my top recommendation for anyone seeking ENT care in Mysore.</p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="testimonial__item">
                            <div class="testimonial__author">
                                <div class="testimonial__author__icon">
                                    <i class="fa fa-quote-left"></i>
                                </div>
                                <div class="testimonial__author__text">
                                    <h5>Lynn Machado</h5>
                                    <span>Patient</span>
                                </div>
                            </div>
                            <div class="rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <p>Dr. Nishan is courteous, he listens to you, we don't ’t feel rushed, and he is very calming. He promptly diagnosed my 9 year old's recurring condition and suggested coblation adenoidectomy after explaining the procedure in detail. My son was nervous about it, as he had not had surgery before but Dr. Nishan's friendly, calm and supportive demeanor really put him at ease. The surgery and post operative care went exceptionally well. My son can breathe with ease and his hearing improved just two days after surgery and his condition will only get better. Thank you very much Doctor. </p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="testimonial__item">
                            <div class="testimonial__author">
                                <div class="testimonial__author__icon">
                                    <i class="fa fa-quote-left"></i>
                                </div>
                                <div class="testimonial__author__text">
                                    <h5>Rishana D'souza</h5>
                                    <span>Patient's Mother</span>
                                </div>
                            </div>
                            <div class="rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <p>Doctor Nishan is the best ent specialist in Mysore. My daughter had severe headache since three years. I consulted many doctors but there was no use. After taking medicine also her headache not gone. When I consulted doctor Nishan he showed me how my daughters nose is blocked and inside all pus. Then he suggested to do nose surgery. Headache due to sinusitis. Now my daughter is really feeling good. Thank you doctor Nishan. You helped us a lot. I suggest if anyone looking for a ent specialist then please contact doctor Nishan. All the best doctor. </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Testimonials Section End -->

    <!-- Team Section Begin -->
    <section class="team spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="section-title">
                        <h2>Our Expert Doctor</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-4">
                    <div class="team__item">
                        <img src="img/images/img1.png" alt="">
                        <h5>Dr. Nishan </h5>
                        <span>ENT Specialist</span>
                    </div>
                </div>
                <div class="col-8 profile-title">
                    <h4>Work Experience</h4>
                    <p>Leading Corporate Hospitals in Mysuru and other major cities in India</p>
                    <h4>Education and Training</h4>
                    <ul>
                        <li>M.B.B.S, from Mysore Medical college</li>
                        <li>MS (ENT) Gold Medallist from Mysore Medical College</li>
                        <li>Fellowship in Endoscopic Sinus Surgery and Skull Base from MAA ENT, Hyderabad</li>
                    </ul>
                    <h4>Speciality Interests</h4>
                    <ul>
                        <li>Endoscopic sinus surgery</li>
                        <li>Endoscopic anterior skull base surgeries (CSF Leak, skull base Tumor’s etc,)</li>
                        <li>Coblation surgeries</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- Team Section End -->

    <?php include("footer.php");  ?>