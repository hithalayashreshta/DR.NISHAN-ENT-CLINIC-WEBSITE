<?php 
    include("config.php");

    if(isset($_REQUEST["submit"])){
        $name=$_REQUEST['name'];
        $phone=$_REQUEST['phone'];
        $app_date=$_REQUEST['app_date'];
        $treatments=$_REQUEST['treatments'];

       $ins="insert into `appointments`(`name`, `phone`, `app_date`, `treatments`) values('$name', '$phone', '$app_date', '$treatments')";
       if($ins_rs=mysqli_query($con, $ins))
       {
        ?>
        <script>
            alert("Thank You We Received Your Enquiry ");
            window.location.href="index.php";
            </script>
            <?php
       }
       else
       {
        ?>
        <script>
            alert("Try Again ");
            window.location.href="appointment.php";
            </script>
            <?php
       }        
    }
?>