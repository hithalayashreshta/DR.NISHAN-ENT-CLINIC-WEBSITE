<?php
    session_start();
    include("config.php"); 
?>
<!DOCTYPE html>
<html lang="EN">
<?php 
    include("header.php"); 
?>
    <table class="table dt-responsive">
        <tr>
            <th>S.No</th>
            <th>Name</th>
            <th>Ph No</th>
            <th>Treatment</th>
            <th>App Date</th>
        </tr>
        <?php
            $i=1;
            $sel = "select * from appointments where status=0";
            $sel_rs = mysqli_query($con, $sel);
            while($sel_arr = mysqli_fetch_array($sel_rs))
            {
                ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo $sel_arr['name']; ?></td>
                    <td><?php echo $sel_arr['phone']; ?></td>
                    <td><?php echo $sel_arr['treatments']; ?></td>
                    <td><?php echo $sel_arr['app_date']; ?></td>
                </tr>
                <?php
            }
        ?>
    </table>
<?php include("footer.php");  ?>