<!DOCTYPE html>
<html lang="EN">
<?php include("header.php"); ?>
<div class="contact__content">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="contact__pic">
                            <img src="img/contact-pic.jpg" alt="">
                        </div>
                    </div>
                    <div class="treatments__appoinment">
                        <div class="treatments__title">
                            <h4><img src="img/icons/treatments-icon.png" alt=""> Get an appointment</h4>
                        </div>
                        <form action="appointment_request.php" method="post">
                            <input type="text" name="name" placeholder="Name">
                            <input type="text" name="phone" placeholder="Phone Number">
                            <div class="datepicker__item">
                                <input type="text" name="app_date" placeholder="Date" class="datepicker">
                                <i class="fa fa-calendar"></i>
                            </div>
                            <select name="Treatments">
                                <option value="">Problems Related To</option>
                                <option value="Ear">Ear</option>
                                <option value="Nose">Nose</option>
                                <option value="Throat">Throat</option>
                                <option value="Emergency care">Emergency care</option>
                            </select>
                            <input type="submit" name="submit" class="site-btn" value="Book appoitment">
                        </form>
                    </div>
               </div>
 </div>
 
    <!-- Contact Section End -->

    <?php include("footer.php");  ?>