<?php 
    include("config.php");

    if(isset($_REQUEST["submit"])){
        $username=$_REQUEST['username'];
        $password=$_REQUEST['password'];
       

       $fetch="select * from login where username='$username' and password='$password'";
       $abc=mysqli_query($con, $fetch);
       if($fet_arr = mysqli_fetch_array($abc))
       {
            session_start();
            $_SESSION['userid'] == $fet_arr['id'];
            $_SESSION['name'] == $fet_arr['username'];
            ?>
                <script>
                    alert("Login Success");
                    window.location.href="booking_details.php";
                </script>
            <?php
       }
       else
       {
            ?>
                <script>
                    alert("Login Failed! Try Again ");
                    window.location.href="login.php";
                </script>
            <?php
       }        
    }
    else
    {
     ?>
         <script>
             alert("Login Failed! Try Again ");
             window.location.href="login.php";
         </script>
         <?php
    }   
?>