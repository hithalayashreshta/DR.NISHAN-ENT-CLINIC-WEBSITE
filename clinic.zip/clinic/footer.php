
    <!-- Footer Section Begin -->
    <footer class="footer">
        <div class="footer__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2 col-md-2 col-xs-12 col-sm-6">
                        <div class="footer__logo">
                            <a href="#"><img src="img/logo1.png" alt=""></a>
                        </div>
                    </div>
                    
                    <div class="col-lg-1 col-md-1"></div>
                    <div class="col-lg-6 col-md-8">
                        <div class="footer__newslatter">
                            <form action="#">
                                <input type="text" placeholder="Email" class="send">
                                <button type="submit" class="site-btn">Send</button>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-12">
                        <div class="footer__social">
                            <a href="https://www.facebook.com/nishan.null?mibextid=LQQJ4d"  target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="http://wa.me/917411081056?text=hello"  target="_blank"><i class="fa fa-whatsappp"></i></a>
                            <a href="https://www.instagram.com/dr.nishanentclinic?igsh=MWxtYjQya3o5ajVzNQ=="  target="_blank"><i class="fa fa-instagram"></i></a>
                            <a href="tel:+917411081056"  target="_blank"><i class="fa fa-phone"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-3 col-sm-6">
                    <div class="footer__widget">
                        <h5>Quick links</h5>
                        <ul>
                            <li><a href="about.php">About</a></li>
                            <li><a href="#">Treatments</a></li>
                            <li><a href="#">Appointment</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="footer__address">
                        <h5>Contact Us</h5>
                        <ul>
                            <li><i class="fa fa-map-marker"></i> DR. NISHAN ENT CLINIC, Kuvempunagar</li>
                            <li><i class="fa fa-phone"></i> +91-7411081056</li>
                            <li><i class="fa fa-envelope"></i> nishu.mmc@gmail.com</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-6">
                    <div class="footer__map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3898.564541245462!2d76.62304237482917!3d12.277720587977507!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3baf65cfd45792c7%3A0x7fc5e56400a9fa3b!2sDr%20Nishan%20%7C%20Best%20Ent%20Specialist%20In%20Mysore%20%7C%20Otolaryngologist%20In%20Mysore_Health%20Station!5e0!3m2!1sen!2sin!4v1712043784731!5m2!1sen!2sin" style="width:100%; min-height:200px; border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer__copyright">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7">
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        <div class="footer__copyright__text">
                            <p>Copyright &copy; <script>document.write(new Date().getFullYear());</script> All rights reserved | Dr. Nishan ENT Clinic Developed by <a href="https://www.scopycode.com" target="_blank">Scopycode</a></p>
                        </div>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </div>
                    <div class="col-lg-5">
                        <ul>
                            <li>All Rights Reserved</li>
                            <li>Terms & Use</li>
                            <li>Privacy Policy</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/masonry.pkgd.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
</body>

</html>