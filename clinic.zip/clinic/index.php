<?php include("header.php"); ?>


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <!-- Hero Section Begin -->
<div id="slider">  
<div class="slides">  
  <img src="img/images/indexpage2.png" width="100%" />
 </div>
  
  <div class="slides">  
  <img src="img/images/indexpageimg1.png" width="100%" />
</div>
  
  <div class="slides">  
  <img src="img/images/indexpage3.png" width="100%" />
</div> 
  
  <div id="dot"><span class="dot"></span><span class="dot"></span><span class="dot"></span><span class="dot"></span><span class="dot"></span></div>
 </div>
 <div class="row">
    <div class="col-lg-12 text-center">

        <a href="appointment.php" class="primary-btn normal-btn">Appointment</a>
        <a href="tel:+917411081056" class="primary-btn normal-btn">Call Now</a>
    </div>
 </div>


    <!-- Hero Section End -->
    <!-- Chooseus Section Begin -->
    <section class="chooseus spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="section-title">
                        <span>Why choose us?</span>
                        <h2>Offer for you</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="chooseus__item">
                        <img src="img/icons/ci-1.png" alt="">
                        <h5>Advanced equipment</h5>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="chooseus__item">
                        <img src="img/icons/ci-2.png" alt="">
                        <h5>Qualified doctor</h5>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="chooseus__item">
                        <img src="img/icons/ci-3.png" alt="">
                        <h5>Certified treatments</h5>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="chooseus__item">
                        <img src="img/icons/ci-4.png" alt="">
                        <h5>Emergency care</h5>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Chooseus Section End -->

   <!-- who we are Section Begin -->
   <section class="chooseus spad aboutsec">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="section-title">
                        <span>Who we are?</span>
                    </div>
                    <div class="row">
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="chooseus__item">
                                <img src="img/images/img1.png" alt="">                                    
                            </div>
                        </div>
                        <div class="col-lg-9 col-md-6 col-sm-6 automargin">
                            <h2>Dr. Nishan</h2>
                            <P>Dr. Nishan MBBS. MS, ENT (Gold Medalist) 
                            Fellowship in Endoscopic Sinus Surgery and Skull Base. 
                                He is Consultant ENT Surgeon having a good experience in all Ear, Nose, 
                            Throat related issues.He has special interest in Endoscopic Sinus Surgery, 
                            Endoscopic Anterior skull base surgeries(CSF Leak, Skull base Turnours etc.) 
                            Endoscopic DCR, Coblation Surgeries. He has obtained his MBBS and MS ENT 
                            (RCUHS Gold medal) from prestigious Mysore Medical College and Research 
                            Institute, Mysore. Fellowship in Endoscopic Sinus Surgery & skull Base from 
                            MAA ENT. Hyderabad (prof.Dr Meghanandh) which is premier ENT Institute in 
                            South India. He has given Live Surgery Demonstration. Cadaveric dissection in 
                            various workshops. Presented various research materials in National Conferences, 
                            Publications in Indexed journal.
                            </P>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Gallery Begin -->
    <div class="gallery">
        <div class="gallery__container">
            <div class="grid-sizer"></div>
            <div class="gc__item set-bg" data-setbg="img/gallery/pic2.jpg">
                <a href="img/gallery/pic2.jpg" class="image-popup"><i class="fa fa-search-plus"></i></a>
            </div>
            <div class="gc__item set-bg" data-setbg="img/gallery/pic3.jpg">
                <a href="img/gallery/pic3.jpg" class="image-popup"><i class="fa fa-search-plus"></i></a>
            </div>
            <div class="gc__item set-bg" data-setbg="img/gallery/pic9.jpg">
                <a href="img/gallery/pic9.jpg" class="image-popup"><i class="fa fa-search-plus"></i></a>
            </div>
            <div class="gc__item gc__item__large set-bg" data-setbg="img/gallery/pic5.jpg">
                <a href="img/gallery/pic5.jpg" class="image-popup"><i class="fa fa-search-plus"></i></a>
            </div>
            <div class="gc__item set-bg" data-setbg="img/gallery/pic6.jpg">
                <a href="img/gallery/pic6.jpg" class="image-popup"><i class="fa fa-search-plus"></i></a>
            </div>
            <div class="gc__item set-bg" data-setbg="img/images/img9.jpg">
                <a href="img/images/img9.jpg" class="image-popup"><i class="fa fa-search-plus"></i></a>
            </div>
            <div class="gc__item set-bg" data-setbg="img/gallery/pic7.jpg">
                <a href="img/gallery/pic7.jpg" class="image-popup"><i class="fa fa-search-plus"></i></a>
            </div>
        </div>
    </div>
    <!-- Gallery End -->

    <!-- Latest News Begin -->
    <section class="latest spad"  style ="background-color: #d7d7d7;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-6">
                    <div class="section-title">
                        <span>Our News</span>
                        <h2>Tips for healthy ears</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="latest__item">
                        <h5><a href="#">Keep your ears clean </a></h5>
                            <p> Clean your ears regularly, but avoid inserting anything smaller than your elbow into your ear canal. This means no cotton swabs or other objects. Simply use a damp cloth to wipe the outer ear.
                        </p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="latest__item">
                        <h5><a href="#">Avoid inserting objects into your ears</a></h5>
                        <p> Avoid inserting cotton swabs, bobby pins, or other objects into your ears. This can push wax deeper into the ear canal and potentially damage the delicate structures of the ear.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="latest__item">
                        <h5><a href="#">Get regular check-ups</a></h5>
                        <p>Include ear health in your regular medical check-ups. Your healthcare provider can inspect your ears for any signs of problems and provide guidance on maintaining ear health.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Latest News End -->

    <!-- Our treatments -->
    <section class="latest spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-6">
                    <div class="section-title">
                        <h2>Treatments Provided</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="latest__item">
                        <h5><a href="#">Ear Disorders: </a></h5>
                        <ul>
                            <li>Diagnosis and treatment of hearing loss</li>
                            <li>Ear infections and otitis media management</li>
                            <li>Tinnitus evaluation and management</li>
                            <li>Earwax removal (cerumen impaction)</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="latest__item">
                        <h5><a href="#">Nose And Sinus Conditions:</a></h5>
                        <ul>
                            <li>Sinusitis evaluation and treatment</li>
                            <li>Nasal congestion relief</li>
                            <li>Allergic rhinitis management</li>
                            <li>Deviated septum correction</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="latest__item">
                        <h5><a href="#">Throat Disorders:</a></h5>
                        <ul>
                            <li>Evaluation and treatment of sore throat</li>
                            <li>Tonsillitis management</li>
                            <li>Voice disorders assessment and therapy</li>
                            <li>Swallowing difficulties (dysphagia) evaluation</li>
                        </ul>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="latest__item">
                        <h5><a href="#">Head and Neck Conditions:</a></h5>
                        <ul>
                            <li>Thyroid and parathyroid disorders management</li>
                            <li> Head and neck cancer screening</li>
                            <li>Facial plastic and reconstructive surgery</li>
                            <li>Sleep apnea evaluation and treatment</li>
                        </ul>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
     <!-- Our treatments End-->
<?php include("footer.php");  ?>