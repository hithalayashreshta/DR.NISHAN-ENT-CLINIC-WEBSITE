<?php
$server="localhost";
$user="root";
$pass= "";
$db= "clinic";

$con=mysqli_connect($server,$user,$pass,$db);
if(mysqli_connect_errno()){ 
    echo "". mysqli_connect_error();
    exit();
}
?>