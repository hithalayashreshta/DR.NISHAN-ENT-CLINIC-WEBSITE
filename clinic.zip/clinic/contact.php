<!DOCTYPE html>
<html lang="EN">
<?php include("header.php"); ?>
    <!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-option spad set-bg" data-setbg="img/images/cntusbg.png">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Contact Us</h2>
                        <div class="breadcrumb__links">
                            <a href="./index.php">Home</a>
                            <span>Contact</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Contact Section Begin -->
    <section class="contact spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="contact__widget">
                        <div class="contact__widget__icon">
                            <i class="fa fa-map-marker"></i>
                        </div>
                        <div class="contact__widget__text">
                            <h5>Address</h5>
                            <p> DR. NISHAN ENT CLINIC,
                                Opp."Poornima Clinc"
                                Near KSRTC Bus Depot, Kuvempunagar,<br>
                                Mysuru - 570017
                             </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="contact__widget">
                        <div class="contact__widget__icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="contact__widget__text">
                            <h5>Phone number</h5>
                            <p><a href="tel:7411081056" target="_blank">+91-7411081056</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="contact__widget">
                        <div class="contact__widget__icon">
                            <i class="fa fa-envelope"></i>
                        </div>
                        <div class="contact__widget__text">
                            <h5>Email</h5>
                            <p><a href="mailto:nishu.mmc@gmail.com" target="_blank">nishu.mmc@gmail.com</a></p>
                        </div>
                    </div>
                </div>
            </div>
           
        </div>
    </section>
    <!-- Contact Section End -->
    <!--time table starts -->
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="st-shedule">
                    <h2 class="st-shedule-title">Weekly Timetable</h2>
                    <div class="row">
                        <div class="col-12 col-md-3 st-shedule-left">Monday</div>
                        <div class="col-12 col-md-9 st-shedule-right">5:00 PM – 9:00 PM</div>
                        <div class="col-12 col-md-3 st-shedule-left">Tuesday</div>
                        <div class="col-12 col-md-9 st-shedule-right">5:00 PM – 9:00 PM</div>
                        <div class="col-12 col-md-3 st-shedule-left">Wednesday</div>
                        <div class="col-12 col-md-9 st-shedule-right">5:00 PM – 9:00 PM</div>
                        <div class="col-12 col-md-3 st-shedule-left">Thursday</div>
                        <div class="col-12 col-md-9 st-shedule-right">5:00 PM – 9:00 PM</div>
                        <div class="col-12 col-md-3 st-shedule-left">Friday</div>
                        <div class="col-12 col-md-9 st-shedule-right">5:00 PM – 9:00 PM</div>
                        <div class="col-12 col-md-3 st-shedule-left">Saturday</div>
                        <div class="col-12 col-md-9 st-shedule-right">5:00 PM – 9:00 PM</div>
                        <div class="col-12 col-md-3 st-shedule-left">Sunday</div>
                        <div class="col-12 col-md-9 st-shedule-right">Holiday</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-7">
                <img src="img/newpic2.jpg" alt="">
            </div>
        </div>
    </div>
 <!--time table ends -->
    <?php include("footer.php");  ?>